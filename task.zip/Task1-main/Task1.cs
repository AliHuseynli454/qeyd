﻿// ededlerin cemi
//int a = 253;
//int b = 536;
//Console.WriteLine(a + b);

//Daxil edilən ədədin müsbət, mənfi və ya sıfır olduğunu tapın.
//int a = 3;
//if (a > 0)
//    Console.WriteLine("positive");
//else if (a == 0)
//    Console.WriteLine("0");
//else
//    Console.WriteLine("negative");

//Ədədin cüt və ya tək olduğunu yoxlayın.  
//int a = 125;
//if (a % 2 == 1)
//    Console.WriteLine("tekdir");
//else
//    Console.WriteLine("cutdur");

//a, b və c ədədlərini daxil edin. Hansının ən böyük olduğunu tapın.
//int a = 26, b = 256, c = 13;
//if (a < b && a > c)
//    Console.WriteLine("en boyuk = b");
//else if (a > b && b > c)
//    Console.WriteLine("en boyuk = a");
//else
//    Console.WriteLine("en boyuk = c");

//Kvadratın tərəfi verilib, sahəsini tapın.
//int a = 24;
//Console.WriteLine(a * a);

//n ədədinin 3-ə və 7-yə bölünməsini tapın.
//int n = 21;
//if (n % 3 == 0 && n % 7 == 0)
//    Console.WriteLine("n 3e ve 7ye bolunur");
//else
//    Console.WriteLine("n 3e ve 7ye bolunmur");
// p ve q ededi
//int p = 512, q = 212;
//if (p % 2 == 0 && q % 2 == 0)
//    Console.WriteLine(p + q);
//else
//    Console.WriteLine("ədədlərin hər ikisi cüt deyil");

// Telebenin qiymeti
//int a = 96;
//if (a > 90 && a < 100)
//    Console.WriteLine("A");
//if (a > 80 && a < 89)
//    Console.WriteLine("B");
//if (a >70  && a <79)
//    Console.WriteLine("C");
//if (a >60  && a <69)
//    Console.WriteLine("D");
//if (a >0  && a <59)
//    Console.WriteLine("F");
